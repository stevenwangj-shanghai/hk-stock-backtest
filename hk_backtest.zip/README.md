# 港股多因子回测系统 - 本地运行指南

## 快速开始

### 1. 安装 Python
访问 https://www.python.org/downloads/
下载并安装 Python 3.9 或更高版本
（安装时勾选 "Add Python to PATH"）

### 2. 安装依赖
打开命令行（Windows CMD 或 PowerShell），运行：
```
pip install flask akshare pandas
```

### 3. 下载后端代码
将 `app.py` 复制到你本地电脑

### 4. 运行后端
```
python app.py
```
看到 "Running on http://localhost:5000" 即启动成功

### 5. 修改前端 API 地址
打开你的 `index.html`，找到这行：
```javascript
const API_BASE = 'http://163.7.2.140:5000';
```
改成：
```javascript
const API_BASE = 'http://localhost:5000';
```

### 6. 打开浏览器
访问 `index.html` 即可使用

---

## 目录结构
```
hk_backtest/
├── app.py          # 后端服务
├── index.html      # 前端界面
└── README.md       # 本文件
```

## 注意事项
- 后端需要保持运行状态
- 首次运行会自动下载数据（需要网络）
- 如遇防火墙提示，请允许访问
