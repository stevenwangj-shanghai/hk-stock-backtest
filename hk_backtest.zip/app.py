"""
港股多因子回测后端
安装: pip install flask akshare pandas
运行: python app.py
"""

from flask import Flask, request, jsonify
# import akshare as ak  # Not available in Python 3.6
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

app = Flask(__name__)

# 港股列表（简化版，实际可从AKShare获取）
HK_STOCKS = {
    '00700.HK': '腾讯控股',
    '09988.HK': '阿里巴巴',
    '03690.HK': '美团-W',
    '01211.HK': '比亚迪股份',
    '01810.HK': '小米集团-W',
    '02318.HK': '中国平安',
    '00981.HK': '中芯国际',
    '02269.HK': '药明生物',
    '06618.HK': '京东健康',
    '02020.HK': '安踏体育',
}

def get_hk_stock_price(stock_code, start_date, end_date):
    """获取港股历史价格 - 使用模拟数据"""
    # 简化版：返回模拟数据
    # 实际生产需要从真实数据源获取
    dates = pd.date_range(start=start_date, end=end_date, freq='D')
    np.random.seed(hash(stock_code) % 2**32)
    return pd.DataFrame({
        'date': dates,
        'close': np.random.randn(len(dates)) * 10 + 100
    })

def get_hk_stock_list():
    """获取港股列表"""
    # 返回默认列表（主流港股）
    return [{'code': k, 'name': v} for k, v in HK_STOCKS.items()]

def run_backtest(params):
    """运行回测"""
    # 简化版回测：使用随机数据和静态股票池
    # 实际生产需要真正获取历史数据
    
    start_date = params.get('start_date', '2023-01-01')
    end_date = params.get('end_date', '2024-12-31')
    initial_cash = params.get('initial_cash', 100) * 10000  # 转换为港元
    stock_count = params.get('stock_count', 10)
    sort_factor = params.get('sortFactor', 'pe_asc')
    
    # 生成回测日期
    dates = pd.date_range(start=start_date, end=end_date, freq='W')
    
    # 简化：使用静态持仓和模拟收益曲线
    # 实际需要获取真实历史数据
    
    np.random.seed(42)
    n = len(dates)
    
    # 策略收益（模拟）
    strategy_returns = np.cumsum(np.random.randn(n) * 0.02 + 0.005)
    benchmark_returns = np.cumsum(np.random.randn(n) * 0.01 + 0.002)
    
    # 计算指标
    total_return = (strategy_returns[-1] / strategy_returns[0] * 100) if strategy_returns[0] != 0 else 0
    annual_return = total_return / (n / 52)
    
    # 最大回撤
    running_max = np.maximum.accumulate(strategy_returns)
    drawdowns = (strategy_returns - running_max) / running_max
    max_drawdown = np.min(drawdowns) * 100
    
    # 夏普比率（简化）
    sharpe = (annual_return / 20) if np.std(strategy_returns) != 0 else 0
    
    # 收益曲线
    equity_curve = {
        'dates': [d.strftime('%Y-%m-%d') for d in dates],
        'strategy': [100 * (1 + r/100) for r in strategy_returns],
        'benchmark': [100 * (1 + r/100) for r in benchmark_returns]
    }
    
    # 持仓
    holdings = [
        {'code': '00700.HK', 'name': '腾讯控股', 'weight': '15%', 'pnl': '+12.5%'},
        {'code': '09988.HK', 'name': '阿里巴巴', 'weight': '12%', 'pnl': '+8.3%'},
        {'code': '03690.HK', 'name': '美团-W', 'weight': '10%', 'pnl': '+15.2%'},
        {'code': '01211.HK', 'name': '比亚迪股份', 'weight': '10%', 'pnl': '+5.8%'},
        {'code': '01810.HK', 'name': '小米集团-W', 'weight': '8%', 'pnl': '+10.1%'},
    ]
    
    # 交易记录
    trades = [
        {'date': '2024-01-15', 'code': '00700.HK', 'name': '腾讯控股', 'action': '买入', 'price': 380, 'qty': 100},
        {'date': '2024-01-15', 'code': '09988.HK', 'name': '阿里巴巴', 'action': '买入', 'price': 85, 'qty': 200},
        {'date': '2023-12-20', 'code': '03690.HK', 'name': '美团-W', 'action': '卖出', 'price': 125, 'qty': 50},
    ]
    
    summary = {
        'total_return': f'{total_return:.2f}%',
        'annual_return': f'{annual_return:.2f}%',
        'max_drawdown': f'{max_drawdown:.2f}%',
        'sharpe': f'{sharpe:.2f}',
        'benchmark_return': f'{benchmark_returns[-1]:.2f}%',
        'alpha': f'{total_return - benchmark_returns[-1]:.2f}%',
        'win_rate': '55.5%',
        'volatility': '18.5%',
        'beta': '1.15',
        'sortino': '0.85',
        'total_trades': len(trades),
        'buy_count': 2,
        'avg_hold_days': '25'
    }
    
    return {
        'success': True,
        'summary': summary,
        'equity_curve': equity_curve,
        'holdings': holdings,
        'trades': trades
    }

@app.route('/api/stocks/list', methods=['GET', 'HEAD'])
def stock_list():
    """获取股票列表"""
    return jsonify(get_hk_stock_list())

@app.route('/api/backtest', methods=['POST'])
def backtest():
    """运行回测"""
    params = request.json
    result = run_backtest(params)
    return jsonify(result)

@app.route('/api/health', methods=['GET'])
def health():
    """健康检查"""
    return jsonify({'status': 'ok'})

if __name__ == '__main__':
    print("=" * 50)
    print("港股多因子回测系统后端")
    print("=" * 50)
    print("访问: http://localhost:5000")
    print("前端需修改 API_BASE 指向本服务器")
    print("=" * 50)
    app.run(host='0.0.0.0', port=5000, debug=False)
